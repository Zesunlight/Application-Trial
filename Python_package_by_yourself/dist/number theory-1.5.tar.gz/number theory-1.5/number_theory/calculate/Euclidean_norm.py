import math


def euc_norm(n, m):
    return math.hypot(n, m)
